package com.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Sukanya;
import com.service.SukanyaServiceIntf;


@Controller

public class SukanyaController {
		@Autowired
		SukanyaServiceIntf SService;
		
		
	@RequestMapping(value="/sukanya",method=RequestMethod.GET)
	public String getQueryform(){
		return "sukanya";
	}

	
	@RequestMapping(value="/sukanya1", method=RequestMethod.POST)
	public ModelAndView insertForm(HttpServletRequest request,HttpServletResponse response) throws ParseException{
	
	
		String gname = request.getParameter("gname");
		String cname = request.getParameter("cname");
		SimpleDateFormat formatter1=new SimpleDateFormat("yyyy-MM-dd");
		Date udob=formatter1.parse(request.getParameter("udob")); 
		String nationality = request.getParameter("nationality");
		String gaadhar = request.getParameter("gaadhar");
		String address = request.getParameter("address");
		
		Sukanya sukanya = new Sukanya();
		sukanya.setCname(cname);
		sukanya.setGname(gname);
		sukanya.setUdob(udob);
		sukanya.setNationality(nationality);
		sukanya.setGaadhar(gaadhar);
		sukanya.setAddress(address);
		boolean flag=SService.insertForm(sukanya);
		System.out.println("Flag:"+flag);
		ModelAndView mav=new ModelAndView();
		mav.addObject("name",gname);
		if(flag)
			mav.addObject("message is accepted");
		else
			mav.addObject("sorry.........message is not accecepted");
		mav.setViewName("viewsukanya");
		return mav;
	}
	
	@RequestMapping(value="/viewsukanya",method=RequestMethod.GET)
	public ModelAndView ViewUser(){
		List<Sukanya> list=SService.getUser();
		System.out.println(list.size());
		ModelAndView mav=new ModelAndView("viewsukanyarecord");
		mav.addObject("obj",list);
		return  mav;
	}
		
}